import sys
from urllib.parse import quote
from PyQt5.QtWidgets import (QMainWindow, QApplication, QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
                             QLineEdit, QTabWidget, QDialog, QFormLayout, QCheckBox, QListWidget, QListWidgetItem, QMessageBox)
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import QUrl, Qt
from PyQt5.QtWebEngineWidgets import QWebEngineView, QWebEnginePage, QWebEngineProfile

site_permissions = {}
browser_history = []
default_search_engine = "https://duckduckgo.com"
custom_search_engine = default_search_engine

class SettingsDialog(QDialog):
    def __init__(self, page, url, parent=None):
        super(SettingsDialog, self).__init__(parent)
        self.setWindowTitle("Settings")
        self.page = page
        self.url = url
        self.layout = QFormLayout(self)
        self.camera_checkbox = QCheckBox("Allow Camera")
        self.mic_checkbox = QCheckBox("Allow Microphone")
        self.layout.addRow("Camera Access:", self.camera_checkbox)
        self.layout.addRow("Microphone Access:", self.mic_checkbox)
        self.custom_search_engine_edit = QLineEdit()
        self.custom_search_engine_edit.setPlaceholderText("Enter Custom Search Engine URL")
        self.layout.addRow("Custom Search Engine:", self.custom_search_engine_edit)
        self.save_btn = QPushButton("Save")
        self.save_btn.clicked.connect(self.save_settings)
        self.layout.addWidget(self.save_btn)
        self.initialize_permissions()
        self.camera_checkbox.stateChanged.connect(self.update_permissions)
        self.mic_checkbox.stateChanged.connect(self.update_permissions)

    def initialize_permissions(self):
        permissions = site_permissions.get(self.url, {})
        self.camera_checkbox.setChecked(permissions.get('camera', False))
        self.mic_checkbox.setChecked(permissions.get('mic', False))
        self.custom_search_engine_edit.setText(custom_search_engine)

    def update_permissions(self):
        permissions = {
            'camera': self.camera_checkbox.isChecked(),
            'mic': self.mic_checkbox.isChecked()
        }
        site_permissions[self.url] = permissions
        self.apply_permissions()

    def apply_permissions(self):
        permissions = site_permissions.get(self.url, {})
        self.page.setFeaturePermission(QUrl(self.url), QWebEnginePage.MediaAudioCapture,
                                        QWebEnginePage.PermissionGrantedByUser if permissions.get('mic', False) else QWebEnginePage.PermissionDeniedByUser)
        self.page.setFeaturePermission(QUrl(self.url), QWebEnginePage.MediaVideoCapture,
                                        QWebEnginePage.PermissionGrantedByUser if permissions.get('camera', False) else QWebEnginePage.PermissionDeniedByUser)

    def save_settings(self):
        global custom_search_engine
        new_search_engine = self.custom_search_engine_edit.text().strip()
        if new_search_engine:
            custom_search_engine = new_search_engine
        self.accept()

class CustomWebEnginePage(QWebEnginePage):
    def __init__(self, profile, parent=None):
        super(CustomWebEnginePage, self).__init__(profile, parent)
        self.profile = profile

    def featurePermissionRequested(self, url, feature):
        if feature == QWebEnginePage.MediaAudioCapture or feature == QWebEnginePage.MediaVideoCapture:
            permission = QWebEnginePage.PermissionGrantedByUser if site_permissions.get(url.toString(), {}).get('mic' if feature == QWebEnginePage.MediaAudioCapture else 'camera', False) else QWebEnginePage.PermissionDeniedByUser
            self.setFeaturePermission(url, feature, permission)

class HistoryDialog(QDialog):
    def __init__(self, history, parent=None):
        super(HistoryDialog, self).__init__(parent)
        self.setWindowTitle("Browser History")
        self.history = history
        self.layout = QVBoxLayout(self)
        self.history_list = QListWidget()
        self.layout.addWidget(self.history_list)
        self.clear_btn = QPushButton("Clear History")
        self.clear_btn.clicked.connect(self.clear_history)
        self.layout.addWidget(self.clear_btn)
        self.update_history_list()

    def update_history_list(self):
        self.history_list.clear()
        for item in self.history:
            list_item = QListWidgetItem(item)
            self.history_list.addItem(list_item)

    def clear_history(self):
        self.history.clear()
        self.update_history_list()

class MyWebBrowser(QMainWindow):
    def __init__(self, *args, **kwargs):
        super(MyWebBrowser, self).__init__(*args, **kwargs)
        self.setWindowTitle("Net Browser")
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.layout = QVBoxLayout(self.central_widget)
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.header_widget = QWidget()
        self.header_widget.setStyleSheet("background: linear-gradient(to right, #12063b, #09555c);")
        self.header_layout = QHBoxLayout(self.header_widget)
        self.header_layout.setContentsMargins(0, 0, 0, 0)
        self.header_layout.setSpacing(0)
        self.back_btn = QPushButton()
        self.back_btn.setIcon(QIcon("/icons/3114883.png"))
        self.back_btn.setFixedSize(30, 30)
        self.back_btn.setStyleSheet("border-radius: 15px; border: none; background: transparent;")
        self.back_btn.clicked.connect(self.back)
        self.forward_btn = QPushButton()
        self.forward_btn.setIcon(QIcon("/icons/download.png"))
        self.forward_btn.setFixedSize(30, 30)
        self.forward_btn.setStyleSheet("border-radius: 15px; border: none; background: transparent;")
        self.forward_btn.clicked.connect(self.forward)
        self.add_tab_btn = QPushButton("+")
        self.add_tab_btn.setFixedSize(30, 30)
        self.add_tab_btn.setStyleSheet("border-radius: 15px; border: none; color: black; font-weight: bold; font-size: 15px;")
        self.add_tab_btn.clicked.connect(self.add_tab)
        self.refresh_btn = QPushButton()
        self.refresh_btn.setIcon(QIcon("/icons/png-transparent-arrows-refresh-reload-update-simple-files-icon.png"))
        self.refresh_btn.setFixedSize(30, 30)
        self.refresh_btn.setStyleSheet("border-radius: 15px; border: none; background: transparent;")
        self.refresh_btn.clicked.connect(self.refresh_page)
        self.url_bar = QLineEdit()
        self.url_bar.setPlaceholderText("Search or enter URL")
        self.url_bar.setStyleSheet("border-radius: 15px; padding: 6px; border: 1px solid #E32636; background-color: #E32636; color: white;")
        self.url_bar.returnPressed.connect(self.navigate)
        self.settings_btn = QPushButton("Settings")
        self.settings_btn.setFixedSize(70, 30)
        self.settings_btn.setStyleSheet("border-radius: 15px; border: none; background: transparent; color: #E32636;")
        self.settings_btn.clicked.connect(self.open_settings)
        self.history_btn = QPushButton("History")
        self.history_btn.setFixedSize(70, 30)
        self.history_btn.setStyleSheet("border-radius: 15px; border: none; background: transparent; color: #E32636;")
        self.history_btn.clicked.connect(self.open_history)
        self.header_layout.addWidget(self.back_btn)
        self.header_layout.addWidget(self.forward_btn)
        self.header_layout.addWidget(self.add_tab_btn)
        self.header_layout.addWidget(self.refresh_btn)
        self.header_layout.addWidget(self.url_bar)
        self.header_layout.addWidget(self.settings_btn)
        self.header_layout.addWidget(self.history_btn)
        self.layout.addWidget(self.header_widget)
        self.tabs = QTabWidget()
        self.tabs.setTabsClosable(True)
        self.tabs.tabCloseRequested.connect(self.close_tab)
        self.tabs.currentChanged.connect(self.current_tab_changed)
        self.layout.addWidget(self.tabs)
        self.add_tab()

    def add_tab(self):
        new_tab = QWebEngineView()
        new_tab.setPage(CustomWebEnginePage(QWebEngineProfile.defaultProfile(), new_tab))
        new_tab.setUrl(QUrl(custom_search_engine))
        index = self.tabs.addTab(new_tab, "New Tab")
        self.tabs.setCurrentIndex(index)
        new_tab.urlChanged.connect(lambda url: self.update_url_bar(url))
        new_tab.titleChanged.connect(lambda title: self.update_tab_title(index, title))
        new_tab.loadFinished.connect(self.update_history_on_load)

    def close_tab(self, index):
        if self.tabs.count() > 1:
            self.tabs.removeTab(index)
        else:
            QMessageBox.warning(self, "Warning", "Cannot close the last tab.")

    def navigate(self):
        url_text = self.url_bar.text().strip()
        if not url_text:
            return
        if not url_text.startswith(('http://', 'https://', 'www.')):
            encoded_query = quote(url_text)
            search_url = f"{custom_search_engine}?q={encoded_query}"
            url = QUrl(search_url)
        else:
            url = QUrl(url_text)
            if not url.isValid() or url.scheme() not in ['http', 'https']:
                encoded_query = quote(url_text)
                search_url = f"{custom_search_engine}?q={encoded_query}"
                url = QUrl(search_url)
        self.update_url_bar(url)
        self.update_history(url_text)
        self.tabs.currentWidget().setUrl(url)

    def update_url_bar(self, url):
        if url.isValid():
            self.url_bar.setText(url.toString())
            self.url_bar.setCursorPosition(0)

    def update_tab_title(self, index, title):
        if title:
            self.tabs.setTabText(index, title)

    def refresh_page(self):
        self.tabs.currentWidget().reload()

    def back(self):
        self.tabs.currentWidget().back()

    def forward(self):
        self.tabs.currentWidget().forward()

    def current_tab_changed(self, index):
        current_url = self.tabs.currentWidget().url()
        self.update_url_bar(current_url)
        self.update_tab_title(index, self.tabs.currentWidget().title())

    def open_settings(self):
        current_url = self.tabs.currentWidget().url().toString()
        page = self.tabs.currentWidget().page()
        dialog = SettingsDialog(page, current_url, self)
        dialog.exec_()

    def open_history(self):
        dialog = HistoryDialog(browser_history, self)
        dialog.exec_()

    def update_history(self, url_text):
        if url_text and url_text not in browser_history:
            browser_history.append(url_text)
        if len(browser_history) > 100:
            browser_history.pop(0)

    def update_history_on_load(self):
        current_url = self.tabs.currentWidget().url().toString()
        self.update_history(current_url)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    browser = MyWebBrowser()
    browser.show()
    sys.exit(app.exec_())
